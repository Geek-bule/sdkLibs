package com.herman.common.constant;

/**
 * 系统类型
 * Created by herman on 2017/11/27.
 */
public enum DeviceType {
    IOS, ANDROID
}
