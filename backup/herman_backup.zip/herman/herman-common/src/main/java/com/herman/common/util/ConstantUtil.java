package com.herman.common.util;

/**
 * 常量工具类
 * Created by herman on 2017/11/28.
 */
public class ConstantUtil {
}
