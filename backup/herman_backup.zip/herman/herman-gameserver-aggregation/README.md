# herman-gameserver-springmvc-aggregation
springmvc aggregation gameserver
include herman-gameserver-springmvc-bean, herman-gameserver-springmvc-manager, herman-gameserver-springmvc-web, herman-gameserver-springmvc-app and so on
