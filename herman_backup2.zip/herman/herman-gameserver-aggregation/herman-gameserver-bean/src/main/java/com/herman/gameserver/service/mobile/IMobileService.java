package com.herman.gameserver.service.mobile;

/**
 * Created by Administrator on 2018/2/1.
 */
public interface IMobileService {

    /**
     * 获取唯一设备号
     *
     * @return
     */
    public String getDgUdid();

}
