# herman-gameserver-springmvc-aggregation
gameserver aggregation
include herman-gameserver-springmvc-bean, herman-gameserver-springmvc-manager, herman-gameserver-springmvc-web, herman-gameserver-springmvc-app and so on
