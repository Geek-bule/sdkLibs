package com.herman.gameserver.game.dto;

import java.io.Serializable;

/**
 * Created by herman on 2018/2/6.
 */
public class GameRecordDto implements Serializable {
    private static final long serialVersionUID = -8514873482014581653L;

    /**
     * 游戏id
     */
    private Long gameId;

    /**
     * 账号内部识别标识
     */
    private String dgAccount;

    /**
     * 游戏记录
     */
    private String record;

    public Long getGameId() {
        return gameId;
    }

    public void setGameId(Long gameId) {
        this.gameId = gameId;
    }

    public String getDgAccount() {
        return dgAccount;
    }

    public void setDgAccount(String dgAccount) {
        this.dgAccount = dgAccount;
    }

    public String getRecord() {
        return record;
    }

    public void setRecord(String record) {
        this.record = record;
    }

    @Override
    public String toString() {
        return "GameRecordDto{" +
                "gameId=" + gameId +
                ", dgAccount='" + dgAccount + '\'' +
                ", record='" + record + '\'' +
                '}';
    }
}
