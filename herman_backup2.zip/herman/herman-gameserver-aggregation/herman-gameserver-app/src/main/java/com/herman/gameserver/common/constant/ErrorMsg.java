package com.herman.gameserver.common.constant;

import java.util.HashMap;
import java.util.Map;

/**
 * 失败信息统一管理类
 * Created by herman on 2018/2/6.
 */
public class ErrorMsg {

    public static Map<String, String> errMap = new HashMap<String, String>();

    // 服务器异常，返回-1
    public static final String SERVER_ERR_CODE = "-1";
    // 接口参数错误，返回错误代码1000~1999
    public static final String REQUEST_PARAM_ERR_CODE = "1000"; // TODO 可细化哪个参数错误
    // 关于设备相关错误，返回错误代码2000~2099
    public static final String INVALID_DGUDID_ERR_CODE = "2000";
    // 关于帐号相关错误，返回错误代码2100~2199

    // 关于游戏记录相关错误，返回错误代码2200~2299
    public static final String INVALID_RECORD_ERR_CODE = "2200";


    static {
        errMap.put(SERVER_ERR_CODE, "系统错误");
        errMap.put(REQUEST_PARAM_ERR_CODE, "请求参数错误");
        errMap.put(INVALID_DGUDID_ERR_CODE, "无效dgUdid");
        errMap.put(INVALID_RECORD_ERR_CODE, "无游戏记录");
    }


    /**
     * 通过失败码查询对应的失败原因
     * @param code
     * @return
     */
    public static String getMsg(String code) {
        return errMap.get(code);
    }

}
