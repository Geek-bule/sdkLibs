package com.herman.common.util;

/**
 * Created by herman on 2018/2/6.
 */
public class ValidateUtil {

    /**
     * 验证字符串是否为空
     * @param str
     * @return
     */
    public static boolean isEmpty(String str) {
        return str == null || "".equals(str);
    }

    /**
     * 验证字符串是否为空
     * @param str
     * @return
     */
    public static boolean isNotEmpty(String str) {
        return !isEmpty(str);
    }

    /**
     * 验证字符串最大长度
     * @param str
     * @return
     */
    public static boolean isAllowMaxLength(String str, int length) {
        return isNotEmpty(str) && str.length() <= length;
    }

    /**
     * 验证字符串最小长度
     * @param str
     * @return
     */
    public static boolean isAllowMinLength(String str, int length) {
        return isNotEmpty(str) && str.length() >= length;
    }

}
